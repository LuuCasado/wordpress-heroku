# WPGraphiQL

This is a React app built with Create React App and implementing: 

- GraphiQL
- GraphiQL Explorer
- GraphiQL Code Exporter
